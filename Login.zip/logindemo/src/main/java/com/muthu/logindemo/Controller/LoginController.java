package com.muthu.logindemo.Controller;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.muthu.logindemo.Model.LoginModel;
import com.muthu.logindemo.Service.LoginService;

import org.springframework.ui.Model;

@Controller
public class LoginController {

	
	@Autowired
	LoginService log;
	
	@GetMapping("/login")
	public String getlogin()
	{
		return "login";
	}
	@PostMapping("/Login")
    public String login(@ModelAttribute("login") LoginModel login) {
        LoginModel loggedInUser = log.userin(login.getEmail(),login.getPassword());

        if (Objects.nonNull(loggedInUser)) {
            return "welcome";
        } else {
            return "Login";
        }
    }

	
    @GetMapping("/reg")
    public String getreges()
	{
		return "register";
	}
	
    @GetMapping("/log")
    public String getlog()
	{
		return "login";
	}
	@PostMapping("/register")
	public String getdata(@ModelAttribute LoginModel login,Model model)
	{
		System.out.println(login.toString());
		log.addvalue(login);
		return "login";
	}
	
	
}
