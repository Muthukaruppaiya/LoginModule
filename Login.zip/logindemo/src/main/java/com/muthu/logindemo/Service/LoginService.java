package com.muthu.logindemo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.muthu.logindemo.Model.LoginModel;
import com.muthu.logindemo.Repo.LoginRepo;

@Service
public class LoginService {

	@Autowired 
	LoginRepo repo;
	
	public void addvalue(LoginModel login) {
		repo.save(login);
	}

	public LoginModel userin(String email, String password) {
        return repo.findByEmailAndPassword(email, password);
    }

}
